# BIT-3108 Scripting Languages Final Practical Exam
# University of Saint Joseph Mbarara Intranet Website

## Student: [Your Name]
## Date: December 2025
## Exam: Final Practical Exam

## PROJECT FEATURES IMPLEMENTED:

### 1. Django Project Structure (Question 3a)
- Project: usjm_website
- App: main
- MVT architecture followed
- All required Django files created

### 2. Python Scripting in Django Models (Question 3b)
- Department model with name and description fields
- ContactMessage model with name, email, message fields
- Django ORM query: `Department.objects.all()`
- Admin interface for data management

### 3. CSS Styling (Question 3c)
- Responsive design using CSS Grid and Flexbox
- Navigation bar with hover effects
- Consistent color scheme (#003366 university colors)
- Professional footer with contact info
- Mobile-first responsive design

### 4. JavaScript Functionality (Question 3d)
- Form validation with error messages
- Success alerts after form submission
- Dynamic image slider
- Mobile navigation toggle
- DOM manipulation (show/hide elements)
- Interactive department cards

## HOW TO RUN:
1. Install Django: `pip install django`
2. Run migrations: `python manage.py migrate`
3. Create superuser: `python manage.py createsuperuser`
4. Start server: `python manage.py runserver`
5. Visit: http://127.0.0.1:8000

## ADMIN CREDENTIALS:
- URL: http://127.0.0.1:8000/admin
- Username: admin
- Password: admin123

## CONTACT:
- University: University of Saint Joseph Mbarara
- Email: usj@usj.ac.ug
- Website: www.usj.ac.ug
- Course: BIT-3108 Scripting Languages

#!/bin/bash
echo "=== Testing USJM Website ==="
echo "1. Starting Django server..."
python3 manage.py runserver &
SERVER_PID=$!
sleep 3

echo "2. Testing URLs..."
curl -s -o /dev/null -w "Home page: %{http_code}\n" http://127.0.0.1:8000/
curl -s -o /dev/null -w "About page: %{http_code}\n" http://127.0.0.1:8000/about/
curl -s -o /dev/null -w "Departments: %{http_code}\n" http://127.0.0.1:8000/departments/
curl -s -o /dev/null -w "Contact page: %{http_code}\n" http://127.0.0.1:8000/contact/
curl -s -o /dev/null -w "Admin panel: %{http_code}\n" http://127.0.0.1:8000/admin/

echo "3. Checking database..."
python3 manage.py shell -c "
from main.models import Department, ContactMessage
print(f'Departments in DB: {Department.objects.count()}')
print(f'Contact messages: {ContactMessage.objects.count()}')
"

echo "4. Stopping server..."
kill $SERVER_PID 2>/dev/null

echo "=== Test Complete ==="
echo "Access at: http://127.0.0.1:8000"
echo "Admin: http://127.0.0.1:8000/admin (admin/admin123)"

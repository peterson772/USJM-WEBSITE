// Question 3d: JavaScript Functionality

document.addEventListener('DOMContentLoaded', function() {
    console.log('USJM Intranet JavaScript loaded');
    
    // Question 3d-i: Mobile menu toggle
    const menuToggle = document.getElementById('menuToggle');
    const navMenu = document.getElementById('navMenu');
    
    if (menuToggle && navMenu) {
        menuToggle.addEventListener('click', function() {
            navMenu.classList.toggle('active');
        });
    }
    
    // Question 3d-ii: Dynamic image slider
    const initImageSlider = () => {
        const slider = document.querySelector('.image-slider');
        if (!slider) return;
        
        const slides = slider.querySelectorAll('.slide');
        let currentSlide = 0;
        
        function showSlide(index) {
            slides.forEach((slide, i) => {
                slide.style.display = i === index ? 'block' : 'none';
            });
        }
        
        function nextSlide() {
            currentSlide = (currentSlide + 1) % slides.length;
            showSlide(currentSlide);
        }
        
        // Auto-advance every 5 seconds
        setInterval(nextSlide, 5000);
        showSlide(0);
    };
    
    initImageSlider();
    
    // Question 3d-iii: DOM manipulation - Show/Hide sections
    const toggleButtons = document.querySelectorAll('.toggle-btn');
    toggleButtons.forEach(button => {
        button.addEventListener('click', function() {
            const targetId = this.getAttribute('data-target');
            const targetElement = document.getElementById(targetId);
            if (targetElement) {
                if (targetElement.style.display === 'none') {
                    targetElement.style.display = 'block';
                    this.textContent = this.getAttribute('data-hide') || 'Hide';
                } else {
                    targetElement.style.display = 'none';
                    this.textContent = this.getAttribute('data-show') || 'Show';
                }
            }
        });
    });
    
    // Question 3d-iv: Form validation
    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const name = document.getElementById('name').value.trim();
            const email = document.getElementById('email').value.trim();
            const message = document.getElementById('message').value.trim();
            
            let isValid = true;
            let errorMessage = '';
            
            // Clear previous errors
            document.querySelectorAll('.error').forEach(el => el.remove());
            
            // Validate name
            if (name.length < 2) {
                isValid = false;
                showError('name', 'Name must be at least 2 characters');
            }
            
            // Validate email
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(email)) {
                isValid = false;
                showError('email', 'Please enter a valid email address');
            }
            
            // Validate message
            if (message.length < 10) {
                isValid = false;
                showError('message', 'Message must be at least 10 characters');
            }
            
            if (isValid) {
                // Question 3d-i: Success alert
                alert('Message submitted successfully!');
                
                // In a real application, you would submit the form here
                // For demo purposes, we'll just show a success message
                const successDiv = document.createElement('div');
                successDiv.className = 'success-message';
                successDiv.textContent = 'Thank you! Your message has been sent.';
                contactForm.parentNode.insertBefore(successDiv, contactForm.nextSibling);
                
                // Clear form
                contactForm.reset();
                
                // Remove success message after 5 seconds
                setTimeout(() => {
                    if (successDiv.parentNode) {
                        successDiv.parentNode.removeChild(successDiv);
                    }
                }, 5000);
            }
            
            return false;
        });
    }
    
    // Helper function for showing errors
    function showError(fieldId, message) {
        const field = document.getElementById(fieldId);
        if (!field) return;
        
        const errorDiv = document.createElement('div');
        errorDiv.className = 'error-message';
        errorDiv.textContent = message;
        field.parentNode.appendChild(errorDiv);
        field.style.borderColor = '#dc3545';
        
        // Remove error after 5 seconds
        setTimeout(() => {
            if (errorDiv.parentNode) {
                errorDiv.parentNode.removeChild(errorDiv);
            }
            field.style.borderColor = '';
        }, 5000);
    }
    
    // Add some interactive elements to the page
    const addInteractiveElements = () => {
        // Add click effect to department cards
        const departmentCards = document.querySelectorAll('.department-card');
        departmentCards.forEach(card => {
            card.addEventListener('click', function() {
                this.style.transform = 'scale(0.98)';
                setTimeout(() => {
                    this.style.transform = '';
                }, 200);
            });
        });
        
        // Add smooth scrolling for anchor links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                e.preventDefault();
                const targetId = this.getAttribute('href');
                if (targetId === '#') return;
                
                const targetElement = document.querySelector(targetId);
                if (targetElement) {
                    targetElement.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        });
    };
    
    addInteractiveElements();
});

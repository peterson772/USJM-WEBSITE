from django.shortcuts import render

def home(request):
    return render(request, 'main/home.html')

def about(request):
    return render(request, 'main/about.html')

def departments(request):
    departments = [
        {'name': 'Computer Science', 'description': 'BSc in Computer Science and IT'},
        {'name': 'Business', 'description': 'Bachelor of Business Administration'},
        {'name': 'Education', 'description': 'Bachelor of Education'},
        {'name': 'Nursing', 'description': 'BSc in Nursing and Health Sciences'},
    ]
    return render(request, 'main/departments.html', {'departments': departments})

def contact(request):
    return render(request, 'main/contact.html')

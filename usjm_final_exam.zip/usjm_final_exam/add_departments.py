import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'usjm_website.settings')
django.setup()

from main.models import Department

departments = [
    ('Computer Science & IT', 'Bachelor of Computer Science, Information Technology, and Software Engineering programs.'),
    ('Business Administration', 'Bachelor of Business Administration, Accounting, Finance, and Management programs.'),
    ('Education', 'Bachelor of Education (Arts & Sciences), Early Childhood Education, and Special Needs Education.'),
    ('Nursing & Health Sciences', 'Bachelor of Nursing, Public Health, Clinical Medicine, and Medical Laboratory Science.'),
    ('Social Sciences', 'Bachelor of Social Sciences, Social Work, Development Studies, and Psychology.'),
    ('Law', 'Bachelor of Laws (LLB) program with practical legal training components.'),
]

Department.objects.all().delete()  # Clear existing

for name, desc in departments:
    Department.objects.create(name=name, description=desc)
    print(f"✓ Added: {name}")

print("Sample departments added successfully!")
